﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmSpecialFormat
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        rbULDASH = New RadioButton()
        rbULD = New RadioButton()
        rbULDASHDD = New RadioButton()
        rbULDASHD = New RadioButton()
        rbULHWAVE = New RadioButton()
        rbULDB = New RadioButton()
        rbULLDASH = New RadioButton()
        rbULTHD = New RadioButton()
        rbULTH = New RadioButton()
        rbULTHDASHD = New RadioButton()
        rbULTHDASH = New RadioButton()
        rbULTHLDASH = New RadioButton()
        rbULTHDASHDD = New RadioButton()
        rbULW = New RadioButton()
        rbULULDBWAVE = New RadioButton()
        rbEMBO = New RadioButton()
        rbULWAVE = New RadioButton()
        rbIMPR = New RadioButton()
        rbSHAD = New RadioButton()
        btnCLEAR = New Button()
        btnAPPLY = New Button()
        rbSCAPS = New RadioButton()
        rbSUPER = New RadioButton()
        rbSUB = New RadioButton()
        rbBULLET = New RadioButton()
        SuspendLayout()
        ' 
        ' rbULDASH
        ' 
        rbULDASH.AutoSize = True
        rbULDASH.Font = New Font("SF Electrotome", 11.25F, FontStyle.Regular, GraphicsUnit.Point)
        rbULDASH.ForeColor = SystemColors.ControlDarkDark
        rbULDASH.Location = New Point(12, 40)
        rbULDASH.Name = "rbULDASH"
        rbULDASH.Size = New Size(104, 21)
        rbULDASH.TabIndex = 65
        rbULDASH.TabStop = True
        rbULDASH.Text = "Dash underline"
        rbULDASH.UseVisualStyleBackColor = True
        ' 
        ' rbULD
        ' 
        rbULD.AutoSize = True
        rbULD.Font = New Font("SF Electrotome", 11.25F, FontStyle.Regular, GraphicsUnit.Point)
        rbULD.ForeColor = SystemColors.ControlDarkDark
        rbULD.Location = New Point(12, 12)
        rbULD.Name = "rbULD"
        rbULD.Size = New Size(114, 21)
        rbULD.TabIndex = 64
        rbULD.TabStop = True
        rbULD.Text = "Dotted underline"
        rbULD.UseVisualStyleBackColor = True
        ' 
        ' rbULDASHDD
        ' 
        rbULDASHDD.AutoSize = True
        rbULDASHDD.Font = New Font("SF Electrotome", 11.25F, FontStyle.Regular, GraphicsUnit.Point)
        rbULDASHDD.ForeColor = SystemColors.ControlDarkDark
        rbULDASHDD.Location = New Point(12, 95)
        rbULDASHDD.Name = "rbULDASHDD"
        rbULDASHDD.Size = New Size(146, 21)
        rbULDASHDD.TabIndex = 67
        rbULDASHDD.TabStop = True
        rbULDASHDD.Text = "Dash dot dot underline"
        rbULDASHDD.UseVisualStyleBackColor = True
        ' 
        ' rbULDASHD
        ' 
        rbULDASHD.AutoSize = True
        rbULDASHD.Font = New Font("SF Electrotome", 11.25F, FontStyle.Regular, GraphicsUnit.Point)
        rbULDASHD.ForeColor = SystemColors.ControlDarkDark
        rbULDASHD.Location = New Point(12, 67)
        rbULDASHD.Name = "rbULDASHD"
        rbULDASHD.Size = New Size(125, 21)
        rbULDASHD.TabIndex = 66
        rbULDASHD.TabStop = True
        rbULDASHD.Text = "Dash dot underline"
        rbULDASHD.UseVisualStyleBackColor = True
        ' 
        ' rbULHWAVE
        ' 
        rbULHWAVE.AutoSize = True
        rbULHWAVE.Font = New Font("SF Electrotome", 11.25F, FontStyle.Regular, GraphicsUnit.Point)
        rbULHWAVE.ForeColor = SystemColors.ControlDarkDark
        rbULHWAVE.Location = New Point(12, 150)
        rbULHWAVE.Name = "rbULHWAVE"
        rbULHWAVE.Size = New Size(143, 21)
        rbULHWAVE.TabIndex = 69
        rbULHWAVE.TabStop = True
        rbULHWAVE.Text = "Heavy wave underline"
        rbULHWAVE.UseVisualStyleBackColor = True
        ' 
        ' rbULDB
        ' 
        rbULDB.AutoSize = True
        rbULDB.Font = New Font("SF Electrotome", 11.25F, FontStyle.Regular, GraphicsUnit.Point)
        rbULDB.ForeColor = SystemColors.ControlDarkDark
        rbULDB.Location = New Point(12, 122)
        rbULDB.Name = "rbULDB"
        rbULDB.Size = New Size(114, 21)
        rbULDB.TabIndex = 68
        rbULDB.TabStop = True
        rbULDB.Text = "Double underline"
        rbULDB.UseVisualStyleBackColor = True
        ' 
        ' rbULLDASH
        ' 
        rbULLDASH.AutoSize = True
        rbULLDASH.Font = New Font("SF Electrotome", 11.25F, FontStyle.Regular, GraphicsUnit.Point)
        rbULLDASH.ForeColor = SystemColors.ControlDarkDark
        rbULLDASH.Location = New Point(12, 177)
        rbULLDASH.Name = "rbULLDASH"
        rbULLDASH.Size = New Size(132, 21)
        rbULLDASH.TabIndex = 70
        rbULLDASH.TabStop = True
        rbULLDASH.Text = "Long dash underline"
        rbULLDASH.UseVisualStyleBackColor = True
        ' 
        ' rbULTHD
        ' 
        rbULTHD.AutoSize = True
        rbULTHD.Font = New Font("SF Electrotome", 11.25F, FontStyle.Regular, GraphicsUnit.Point)
        rbULTHD.ForeColor = SystemColors.ControlDarkDark
        rbULTHD.Location = New Point(12, 232)
        rbULTHD.Name = "rbULTHD"
        rbULTHD.Size = New Size(145, 21)
        rbULTHD.TabIndex = 73
        rbULTHD.TabStop = True
        rbULTHD.Text = "Thick dotted underline"
        rbULTHD.UseVisualStyleBackColor = True
        ' 
        ' rbULTH
        ' 
        rbULTH.AutoSize = True
        rbULTH.Font = New Font("SF Electrotome", 11.25F, FontStyle.Regular, GraphicsUnit.Point)
        rbULTH.ForeColor = SystemColors.ControlDarkDark
        rbULTH.Location = New Point(12, 204)
        rbULTH.Name = "rbULTH"
        rbULTH.Size = New Size(107, 21)
        rbULTH.TabIndex = 72
        rbULTH.TabStop = True
        rbULTH.Text = "Thick underline"
        rbULTH.UseVisualStyleBackColor = True
        ' 
        ' rbULTHDASHD
        ' 
        rbULTHDASHD.AutoSize = True
        rbULTHDASHD.Font = New Font("SF Electrotome", 11.25F, FontStyle.Regular, GraphicsUnit.Point)
        rbULTHDASHD.ForeColor = SystemColors.ControlDarkDark
        rbULTHDASHD.Location = New Point(12, 287)
        rbULTHDASHD.Name = "rbULTHDASHD"
        rbULTHDASHD.Size = New Size(156, 21)
        rbULTHDASHD.TabIndex = 75
        rbULTHDASHD.TabStop = True
        rbULTHDASHD.Text = "Thick dash dot underline"
        rbULTHDASHD.UseVisualStyleBackColor = True
        ' 
        ' rbULTHDASH
        ' 
        rbULTHDASH.AutoSize = True
        rbULTHDASH.Font = New Font("SF Electrotome", 11.25F, FontStyle.Regular, GraphicsUnit.Point)
        rbULTHDASH.ForeColor = SystemColors.ControlDarkDark
        rbULTHDASH.Location = New Point(12, 259)
        rbULTHDASH.Name = "rbULTHDASH"
        rbULTHDASH.Size = New Size(135, 21)
        rbULTHDASH.TabIndex = 74
        rbULTHDASH.TabStop = True
        rbULTHDASH.Text = "Thick dash underline"
        rbULTHDASH.UseVisualStyleBackColor = True
        ' 
        ' rbULTHLDASH
        ' 
        rbULTHLDASH.AutoSize = True
        rbULTHLDASH.Font = New Font("SF Electrotome", 11.25F, FontStyle.Regular, GraphicsUnit.Point)
        rbULTHLDASH.ForeColor = SystemColors.ControlDarkDark
        rbULTHLDASH.Location = New Point(12, 342)
        rbULTHLDASH.Name = "rbULTHLDASH"
        rbULTHLDASH.Size = New Size(161, 21)
        rbULTHLDASH.TabIndex = 77
        rbULTHLDASH.TabStop = True
        rbULTHLDASH.Text = "Thick long dash underline"
        rbULTHLDASH.UseVisualStyleBackColor = True
        ' 
        ' rbULTHDASHDD
        ' 
        rbULTHDASHDD.AutoSize = True
        rbULTHDASHDD.Font = New Font("SF Electrotome", 11.25F, FontStyle.Regular, GraphicsUnit.Point)
        rbULTHDASHDD.ForeColor = SystemColors.ControlDarkDark
        rbULTHDASHDD.Location = New Point(12, 314)
        rbULTHDASHDD.Name = "rbULTHDASHDD"
        rbULTHDASHDD.Size = New Size(177, 21)
        rbULTHDASHDD.TabIndex = 76
        rbULTHDASHDD.TabStop = True
        rbULTHDASHDD.Text = "Thick dash dot dot underline"
        rbULTHDASHDD.UseVisualStyleBackColor = True
        ' 
        ' rbULW
        ' 
        rbULW.AutoSize = True
        rbULW.Font = New Font("SF Electrotome", 11.25F, FontStyle.Regular, GraphicsUnit.Point)
        rbULW.ForeColor = SystemColors.ControlDarkDark
        rbULW.Location = New Point(12, 397)
        rbULW.Name = "rbULW"
        rbULW.Size = New Size(106, 21)
        rbULW.TabIndex = 79
        rbULW.TabStop = True
        rbULW.Text = "Word underline"
        rbULW.UseVisualStyleBackColor = True
        ' 
        ' rbULULDBWAVE
        ' 
        rbULULDBWAVE.AutoSize = True
        rbULULDBWAVE.Font = New Font("SF Electrotome", 11.25F, FontStyle.Regular, GraphicsUnit.Point)
        rbULULDBWAVE.ForeColor = SystemColors.ControlDarkDark
        rbULULDBWAVE.Location = New Point(12, 369)
        rbULULDBWAVE.Name = "rbULULDBWAVE"
        rbULULDBWAVE.Size = New Size(147, 21)
        rbULULDBWAVE.TabIndex = 78
        rbULULDBWAVE.TabStop = True
        rbULULDBWAVE.Text = "Double wave underline"
        rbULULDBWAVE.UseVisualStyleBackColor = True
        ' 
        ' rbEMBO
        ' 
        rbEMBO.AutoSize = True
        rbEMBO.Font = New Font("SF Electrotome", 11.25F, FontStyle.Regular, GraphicsUnit.Point)
        rbEMBO.ForeColor = SystemColors.ControlDarkDark
        rbEMBO.Location = New Point(12, 452)
        rbEMBO.Name = "rbEMBO"
        rbEMBO.Size = New Size(70, 21)
        rbEMBO.TabIndex = 81
        rbEMBO.TabStop = True
        rbEMBO.Text = "Emboss"
        rbEMBO.UseVisualStyleBackColor = True
        ' 
        ' rbULWAVE
        ' 
        rbULWAVE.AutoSize = True
        rbULWAVE.Font = New Font("SF Electrotome", 11.25F, FontStyle.Regular, GraphicsUnit.Point)
        rbULWAVE.ForeColor = SystemColors.ControlDarkDark
        rbULWAVE.Location = New Point(12, 424)
        rbULWAVE.Name = "rbULWAVE"
        rbULWAVE.Size = New Size(108, 21)
        rbULWAVE.TabIndex = 80
        rbULWAVE.TabStop = True
        rbULWAVE.Text = "Wave underline"
        rbULWAVE.UseVisualStyleBackColor = True
        ' 
        ' rbIMPR
        ' 
        rbIMPR.AutoSize = True
        rbIMPR.Font = New Font("SF Electrotome", 11.25F, FontStyle.Regular, GraphicsUnit.Point)
        rbIMPR.ForeColor = SystemColors.ControlDarkDark
        rbIMPR.Location = New Point(12, 479)
        rbIMPR.Name = "rbIMPR"
        rbIMPR.Size = New Size(68, 21)
        rbIMPR.TabIndex = 82
        rbIMPR.TabStop = True
        rbIMPR.Text = "Engrave"
        rbIMPR.UseVisualStyleBackColor = True
        ' 
        ' rbSHAD
        ' 
        rbSHAD.AutoSize = True
        rbSHAD.Font = New Font("SF Electrotome", 11.25F, FontStyle.Regular, GraphicsUnit.Point)
        rbSHAD.ForeColor = SystemColors.ControlDarkDark
        rbSHAD.Location = New Point(12, 614)
        rbSHAD.Name = "rbSHAD"
        rbSHAD.Size = New Size(69, 21)
        rbSHAD.TabIndex = 83
        rbSHAD.TabStop = True
        rbSHAD.Text = "Shadow"
        rbSHAD.UseVisualStyleBackColor = True
        ' 
        ' btnCLEAR
        ' 
        btnCLEAR.BackColor = Color.White
        btnCLEAR.Cursor = Cursors.Hand
        btnCLEAR.Font = New Font("SF Electrotome", 8.25F, FontStyle.Regular, GraphicsUnit.Point)
        btnCLEAR.ForeColor = Color.Navy
        btnCLEAR.Location = New Point(149, 638)
        btnCLEAR.Margin = New Padding(3, 0, 3, 3)
        btnCLEAR.Name = "btnCLEAR"
        btnCLEAR.Size = New Size(48, 20)
        btnCLEAR.TabIndex = 84
        btnCLEAR.Text = "CLEAR"
        btnCLEAR.TextAlign = ContentAlignment.TopCenter
        btnCLEAR.UseVisualStyleBackColor = False
        ' 
        ' btnAPPLY
        ' 
        btnAPPLY.BackColor = Color.White
        btnAPPLY.Cursor = Cursors.Hand
        btnAPPLY.Font = New Font("SF Electrotome", 8.25F, FontStyle.Regular, GraphicsUnit.Point)
        btnAPPLY.ForeColor = Color.Navy
        btnAPPLY.Location = New Point(12, 638)
        btnAPPLY.Margin = New Padding(3, 0, 3, 3)
        btnAPPLY.Name = "btnAPPLY"
        btnAPPLY.Size = New Size(50, 20)
        btnAPPLY.TabIndex = 85
        btnAPPLY.Text = "APPLY"
        btnAPPLY.TextAlign = ContentAlignment.TopCenter
        btnAPPLY.UseVisualStyleBackColor = False
        ' 
        ' rbSCAPS
        ' 
        rbSCAPS.AutoSize = True
        rbSCAPS.Font = New Font("SF Electrotome", 11.25F, FontStyle.Regular, GraphicsUnit.Point)
        rbSCAPS.ForeColor = SystemColors.ControlDarkDark
        rbSCAPS.Location = New Point(12, 506)
        rbSCAPS.Name = "rbSCAPS"
        rbSCAPS.Size = New Size(101, 21)
        rbSCAPS.TabIndex = 86
        rbSCAPS.TabStop = True
        rbSCAPS.Text = "Small capitals"
        rbSCAPS.UseVisualStyleBackColor = True
        ' 
        ' rbSUPER
        ' 
        rbSUPER.AutoSize = True
        rbSUPER.Font = New Font("SF Electrotome", 11.25F, FontStyle.Regular, GraphicsUnit.Point)
        rbSUPER.ForeColor = SystemColors.ControlDarkDark
        rbSUPER.Location = New Point(12, 560)
        rbSUPER.Name = "rbSUPER"
        rbSUPER.Size = New Size(94, 21)
        rbSUPER.TabIndex = 88
        rbSUPER.TabStop = True
        rbSUPER.Text = "Superscripts"
        rbSUPER.UseVisualStyleBackColor = True
        ' 
        ' rbSUB
        ' 
        rbSUB.AutoSize = True
        rbSUB.Font = New Font("SF Electrotome", 11.25F, FontStyle.Regular, GraphicsUnit.Point)
        rbSUB.ForeColor = SystemColors.ControlDarkDark
        rbSUB.Location = New Point(12, 533)
        rbSUB.Name = "rbSUB"
        rbSUB.Size = New Size(84, 21)
        rbSUB.TabIndex = 87
        rbSUB.TabStop = True
        rbSUB.Text = "Subscripts"
        rbSUB.UseVisualStyleBackColor = True
        ' 
        ' rbBULLET
        ' 
        rbBULLET.AutoSize = True
        rbBULLET.Font = New Font("SF Electrotome", 11.25F, FontStyle.Regular, GraphicsUnit.Point)
        rbBULLET.ForeColor = SystemColors.ControlDarkDark
        rbBULLET.Location = New Point(12, 587)
        rbBULLET.Name = "rbBULLET"
        rbBULLET.Size = New Size(57, 21)
        rbBULLET.TabIndex = 88
        rbBULLET.TabStop = True
        rbBULLET.Text = "Bullet"
        rbBULLET.UseVisualStyleBackColor = True
        ' 
        ' FrmSpecialFormat
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(209, 666)
        Controls.Add(rbBULLET)
        Controls.Add(rbSUPER)
        Controls.Add(rbSUB)
        Controls.Add(rbSCAPS)
        Controls.Add(btnAPPLY)
        Controls.Add(btnCLEAR)
        Controls.Add(rbSHAD)
        Controls.Add(rbIMPR)
        Controls.Add(rbEMBO)
        Controls.Add(rbULWAVE)
        Controls.Add(rbULW)
        Controls.Add(rbULULDBWAVE)
        Controls.Add(rbULTHLDASH)
        Controls.Add(rbULTHDASHDD)
        Controls.Add(rbULTHDASHD)
        Controls.Add(rbULTHDASH)
        Controls.Add(rbULTHD)
        Controls.Add(rbULTH)
        Controls.Add(rbULLDASH)
        Controls.Add(rbULHWAVE)
        Controls.Add(rbULDB)
        Controls.Add(rbULDASHDD)
        Controls.Add(rbULDASHD)
        Controls.Add(rbULDASH)
        Controls.Add(rbULD)
        FormBorderStyle = FormBorderStyle.FixedToolWindow
        Name = "FrmSpecialFormat"
        Text = "Special format"
        TopMost = True
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents rbULDASH As RadioButton
    Friend WithEvents rbULD As RadioButton
    Friend WithEvents rbULDASHDD As RadioButton
    Friend WithEvents rbULDASHD As RadioButton
    Friend WithEvents rbULHWAVE As RadioButton
    Friend WithEvents rbULDB As RadioButton
    Friend WithEvents rbULLDASH As RadioButton
    Friend WithEvents rbULTHD As RadioButton
    Friend WithEvents rbULTH As RadioButton
    Friend WithEvents rbULTHDASHD As RadioButton
    Friend WithEvents rbULTHDASH As RadioButton
    Friend WithEvents rbULTHLDASH As RadioButton
    Friend WithEvents rbULTHDASHDD As RadioButton
    Friend WithEvents rbULW As RadioButton
    Friend WithEvents rbULULDBWAVE As RadioButton
    Friend WithEvents rbEMBO As RadioButton
    Friend WithEvents rbULWAVE As RadioButton
    Friend WithEvents rbIMPR As RadioButton
    Friend WithEvents rbSHAD As RadioButton
    Friend WithEvents btnCLEAR As Button
    Friend WithEvents btnAPPLY As Button
    Friend WithEvents rbSCAPS As RadioButton
    Friend WithEvents rbSUPER As RadioButton
    Friend WithEvents rbSUB As RadioButton
    Friend WithEvents rbBULLET As RadioButton
End Class
